package com.example.faceattendanceapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AdminDashboardActivity extends AppCompatActivity {

    TextView timeTextView;
    Button logoutButton;

    private Handler handler = new Handler();
    private Runnable timeRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        timeTextView = findViewById(R.id.timeTextView);
        logoutButton = findViewById(R.id.logoutButton);

        // Start live time update
        startLiveTimeUpdate();

        // Logout action
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, AdminLoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void startLiveTimeUpdate() {
        timeRunnable = new Runnable() {
            @Override
            public void run() {
                // Format: Hour:Minute:Second
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
                String currentTime = sdf.format(new Date());
                timeTextView.setText(currentTime);

                // Repeat every second
                handler.postDelayed(this, 1000);
            }
        };

        handler.post(timeRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(timeRunnable); // Stop updates when activity is destroyed
    }
    public void openRegisterStudent(View view) {
        Intent intent = new Intent(this, RegisterStudentActivity.class);
        startActivity(intent);
    }

    // Called when "Change Interval" card is tapped
    public void openChangeInterval(View view) {
        Intent intent = new Intent(this, ChangeIntervalActivity.class);
        startActivity(intent);
    }

    // Called when "View Attendance" card is tapped
    public void openViewAttendance(View view) {
        Intent intent = new Intent(this, ViewAttendanceActivity.class);
        startActivity(intent);
    }

    // Called when "Manage Students" card is tapped
    public void openManageStudents(View view) {
        Intent intent = new Intent(this, ManageStudentsActivity.class);
        startActivity(intent);
    }

    // Called when "Send Mails" card is tapped
    public void openSendMails(View view) {
        Intent intent = new Intent(this, SendMailsActivity.class);
        startActivity(intent);
    }

    // Called when "Change Password" card is tapped
    public void openForgotPassword(View view) {
        Intent intent = new Intent(this, ChangePasswordActivity.class);
        startActivity(intent);
    }
}


