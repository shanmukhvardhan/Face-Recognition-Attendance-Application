package com.example.faceattendanceapp;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class ChangeIntervalActivity extends AppCompatActivity {

    EditText startTimeEditText, endTimeEditText;
    Button changeButton;
    ImageView backArrow;

    int startHour, startMinute, endHour, endMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_interval);

        startTimeEditText = findViewById(R.id.startTime);
        endTimeEditText = findViewById(R.id.endTime);
        changeButton = findViewById(R.id.changeButton);
        backArrow = findViewById(R.id.backArrow);

        // Go back to previous screen
        backArrow.setOnClickListener(v -> onBackPressed());

        // Open time picker for start time
        startTimeEditText.setOnClickListener(v -> {
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    ChangeIntervalActivity.this,
                    (view, hourOfDay, minute) -> {
                        startHour = hourOfDay;
                        startMinute = minute;
                        startTimeEditText.setText(String.format(Locale.getDefault(), "%02d:%02d", startHour, startMinute));
                    },
                    startHour, startMinute, true
            );
            timePickerDialog.show();
        });

        // Open time picker for end time
        endTimeEditText.setOnClickListener(v -> {
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    ChangeIntervalActivity.this,
                    (view, hourOfDay, minute) -> {
                        endHour = hourOfDay;
                        endMinute = minute;
                        endTimeEditText.setText(String.format(Locale.getDefault(), "%02d:%02d", endHour, endMinute));
                    },
                    endHour, endMinute, true
            );
            timePickerDialog.show();
        });

        // Handle Change button
        changeButton.setOnClickListener(v -> {
            String start = startTimeEditText.getText().toString().trim();
            String end = endTimeEditText.getText().toString().trim();

            if (start.isEmpty() || end.isEmpty()) {
                Toast.makeText(this, "Please select both start and end times", Toast.LENGTH_SHORT).show();
                return;
            }

            // TODO: Save to Firebase later
            Toast.makeText(this, "Interval set: " + start + " to " + end, Toast.LENGTH_SHORT).show();
        });
    }
}
