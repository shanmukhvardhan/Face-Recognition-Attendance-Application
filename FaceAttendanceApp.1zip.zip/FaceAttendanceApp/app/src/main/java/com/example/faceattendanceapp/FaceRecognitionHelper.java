package com.example.faceattendanceapp;

import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Bitmap;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class FaceRecognitionHelper {
    private final Interpreter tflite;

    public FaceRecognitionHelper(AssetManager assetManager, String modelPath) throws IOException {
        tflite = new Interpreter(loadModelFile(assetManager, modelPath));
    }

    private MappedByteBuffer loadModelFile(AssetManager assetManager, String path) throws IOException {
        AssetFileDescriptor fileDescriptor = assetManager.openFd(path);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.getStartOffset(), fileDescriptor.getDeclaredLength());
    }

    public float[] getFaceEmbedding(Bitmap bitmap) {
        Bitmap resized = Bitmap.createScaledBitmap(bitmap, 112, 112, true);
        ByteBuffer inputBuffer = ByteBuffer.allocateDirect(1 * 112 * 112 * 3 * 4);
        inputBuffer.order(ByteOrder.nativeOrder());

        for (int y = 0; y < 112; y++) {
            for (int x = 0; x < 112; x++) {
                int px = resized.getPixel(x, y);
                inputBuffer.putFloat(((px >> 16) & 0xFF) / 255.0f); // R
                inputBuffer.putFloat(((px >> 8) & 0xFF) / 255.0f);  // G
                inputBuffer.putFloat((px & 0xFF) / 255.0f);         // B
            }
        }

        float[][] embedding = new float[1][128];
        tflite.run(inputBuffer, embedding);
        return embedding[0];
    }
}
