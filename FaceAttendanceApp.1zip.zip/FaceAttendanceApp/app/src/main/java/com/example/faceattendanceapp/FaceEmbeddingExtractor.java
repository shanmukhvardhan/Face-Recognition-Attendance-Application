package com.example.faceattendanceapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;

import com.google.mlkit.vision.face.Face;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.common.FileUtil;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class FaceEmbeddingExtractor {

    private Interpreter tflite;
    private static final int EMBEDDING_SIZE = 192;
    private static final int INPUT_SIZE = 112;

    public interface EmbeddingCallback {
        void onEmbeddingResult(float[] embedding);
    }

    public FaceEmbeddingExtractor(Context context) {
        try {
            tflite = new Interpreter(FileUtil.loadMappedFile(context, "mobile_face_net.tflite"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getFaceEmbedding(Bitmap bitmap, Face face, EmbeddingCallback callback) {
        Rect bounds = face.getBoundingBox();
        int x = Math.max(bounds.left, 0);
        int y = Math.max(bounds.top, 0);
        int width = Math.min(bounds.width(), bitmap.getWidth() - x);
        int height = Math.min(bounds.height(), bitmap.getHeight() - y);

        Bitmap faceBitmap = Bitmap.createBitmap(bitmap, x, y, width, height);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(faceBitmap, INPUT_SIZE, INPUT_SIZE, true);

        ByteBuffer inputBuffer = convertBitmapToBuffer(resizedBitmap);
        float[][] output = new float[1][EMBEDDING_SIZE];

        tflite.run(inputBuffer, output);
        float[] embedding = output[0];

        new Handler(Looper.getMainLooper()).post(() -> callback.onEmbeddingResult(embedding));
    }

    private ByteBuffer convertBitmapToBuffer(Bitmap bitmap) {
        ByteBuffer buffer = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3);
        buffer.order(ByteOrder.nativeOrder());

        int[] pixels = new int[INPUT_SIZE * INPUT_SIZE];
        bitmap.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE);

        for (int pixel : pixels) {
            buffer.putFloat(((pixel >> 16) & 0xFF) / 255.0f); // R
            buffer.putFloat(((pixel >> 8) & 0xFF) / 255.0f);  // G
            buffer.putFloat((pixel & 0xFF) / 255.0f);         // B
        }

        buffer.rewind();
        return buffer;
    }
}
