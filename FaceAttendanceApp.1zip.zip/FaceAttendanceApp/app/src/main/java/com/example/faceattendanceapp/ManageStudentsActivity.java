package com.example.faceattendanceapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ManageStudentsActivity extends AppCompatActivity {

    private EditText searchBar;
    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private ArrayList<Student> studentList;
    private ArrayList<Student> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_students);

        searchBar = findViewById(R.id.searchBar);
        recyclerView = findViewById(R.id.recyclerView);
        ImageView backArrow = findViewById(R.id.backArrow);

        studentList = new ArrayList<>();
        filteredList = new ArrayList<>();

        adapter = new StudentAdapter(filteredList, student -> showStudentOptions(student));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        loadDummyData(); // Replace with Firebase fetch later
        setupSearch();

        backArrow.setOnClickListener(v -> finish());
    }

    private void loadDummyData() {
        // Replace this with Firebase fetch later
        studentList.add(new Student("101", "Alice", "alice@example.com"));
        studentList.add(new Student("102", "Bob", "bob@example.com"));
        studentList.add(new Student("103", "Charlie", "charlie@example.com"));
        studentList.add(new Student("104", "David", "david@example.com"));

        filteredList.clear();
        filteredList.addAll(studentList);
        adapter.notifyDataSetChanged();
    }

    private void setupSearch() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                filterList(s.toString());
            }
        });
    }

    private void filterList(String query) {
        filteredList.clear();
        for (Student student : studentList) {
            if (student.getName().toLowerCase().contains(query.toLowerCase()) ||
                    student.getId().contains(query)) {
                filteredList.add(student);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void showStudentOptions(Student student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Action")
                .setItems(new String[]{"Edit", "Delete"}, (dialog, which) -> {
                    if (which == 0) {
                        // Edit
                        Intent intent = new Intent(this, EditStudentActivity.class);
                        intent.putExtra("id", student.getId());
                        startActivity(intent);
                    } else {
                        // Delete
                        deleteStudent(student);
                    }
                });
        builder.show();
    }

    private void deleteStudent(Student student) {
        // Firebase delete logic here
        studentList.remove(student);
        filterList(searchBar.getText().toString());
        Toast.makeText(this, "Student deleted", Toast.LENGTH_SHORT).show();
    }
}
