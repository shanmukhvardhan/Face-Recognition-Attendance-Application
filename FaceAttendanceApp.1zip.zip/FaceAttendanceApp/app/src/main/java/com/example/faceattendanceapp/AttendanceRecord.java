package com.example.faceattendanceapp;

public class AttendanceRecord {
    public String name;
    public long timestamp;

    public AttendanceRecord() {
        // Default constructor required for Firebase
    }

    public AttendanceRecord(String name, long timestamp) {
        this.name = name;
        this.timestamp = timestamp;
    }
}
