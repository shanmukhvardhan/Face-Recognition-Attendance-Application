package com.example.faceattendanceapp;

import android.content.Context;
import android.graphics.Bitmap;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.common.FileUtil;

import java.io.IOException;
import java.nio.ByteBuffer;

public class FaceEmbedder {
    private final Interpreter tfLite;

    public FaceEmbedder(Context context) {
        try {
            tfLite = new Interpreter(FileUtil.loadMappedFile(context, "mobile_face_net.tflite"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public float[] getEmbedding(Bitmap faceBitmap) {
        // Preprocess
        Bitmap scaled = Bitmap.createScaledBitmap(faceBitmap, 112, 112, true);
        ByteBuffer inputBuffer = ImageUtils.bitmapToBuffer(scaled);

        float[][] embedding = new float[1][192]; // or 128 based on your model

        tfLite.run(inputBuffer, embedding);
        return embedding[0];
    }
}
