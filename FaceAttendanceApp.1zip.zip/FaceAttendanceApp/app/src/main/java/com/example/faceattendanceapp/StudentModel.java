package com.example.faceattendanceapp;

public class StudentModel {
    public String name;
    public String id;
    public String email;
    public String dept;

    // Required empty constructor for Firebase
    public StudentModel() {}

    public StudentModel(String name, String id, String email, String dept) {
        this.name = name;
        this.id = id;
        this.email = email;
        this.dept = dept;
    }
}
