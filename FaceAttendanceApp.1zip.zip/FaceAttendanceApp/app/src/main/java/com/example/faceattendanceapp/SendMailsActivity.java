package com.example.faceattendanceapp;

public class SendMailsActivity {
}
