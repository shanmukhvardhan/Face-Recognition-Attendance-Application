package com.example.faceattendanceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import androidx.appcompat.app.AppCompatActivity;

public class RegisterStudentActivity extends AppCompatActivity {

    EditText nameInput, idInput, emailInput, deptInput;
    Button submitButton;
    ImageView backArrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_student);

        // Initialize views
        nameInput = findViewById(R.id.nameInput);
        idInput = findViewById(R.id.idInput);
        emailInput = findViewById(R.id.emailInput);
        deptInput = findViewById(R.id.deptInput);
        submitButton = findViewById(R.id.submitButton);
        backArrow = findViewById(R.id.backArrow); // ← Your back arrow ImageView

        // Back Arrow logic
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Close current screen
            }
        });

        // Submit button logic
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerStudent();
            }
        });
    }

    private void registerStudent() {
        String name = nameInput.getText().toString().trim();
        String id = idInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String dept = deptInput.getText().toString().trim();

        if (name.isEmpty() || id.isEmpty() || email.isEmpty() || dept.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a student object
        StudentModel student = new StudentModel(name, id, email, dept);

        // Push to Realtime Database
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("students");
        dbRef.child(id).setValue(student).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(RegisterStudentActivity.this, "Student registered", Toast.LENGTH_SHORT).show();

                // Move to FaceScanActivity
                Intent intent = new Intent(RegisterStudentActivity.this, com.example.faceattendanceapp.FaceScanActivity.class);
                intent.putExtra("studentId", id);
                startActivity(intent);
            } else {
                Toast.makeText(RegisterStudentActivity.this, "Failed to register", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
