package com.example.faceattendanceapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EditStudentActivity extends AppCompatActivity {

    EditText editStudentName, editStudentEmail;
    Button saveButton;

    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student);

        editStudentName = findViewById(R.id.editStudentName);
        editStudentEmail = findViewById(R.id.editStudentEmail);
        saveButton = findViewById(R.id.saveButton);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        String name = intent.getStringExtra("name");
        String email = intent.getStringExtra("email");

        editStudentName.setText(name);
        editStudentEmail.setText(email);

        saveButton.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("id", id);
            resultIntent.putExtra("name", editStudentName.getText().toString());
            resultIntent.putExtra("email", editStudentEmail.getText().toString());
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}
