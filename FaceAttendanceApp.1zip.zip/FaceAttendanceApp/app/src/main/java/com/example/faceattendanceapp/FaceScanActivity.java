package com.example.faceattendanceapp;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FaceScanActivity extends AppCompatActivity {

    private PreviewView previewView;
    private FaceEmbedder faceEmbedder;
    private boolean isCaptured = false;
    private ExecutorService cameraExecutor;
    private Bitmap latestFrameBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_student);

        previewView = findViewById(R.id.previewView);
        faceEmbedder = new FaceEmbedder(this);
        cameraExecutor = Executors.newSingleThreadExecutor();

        startCamera();

        Button captureButton = findViewById(R.id.submitButton);
        captureButton.setOnClickListener(v -> captureAndSaveFace());
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                CameraSelector cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA;

                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

                imageAnalysis.setAnalyzer(cameraExecutor, imageProxy -> {
                    if (!isCaptured) {
                        latestFrameBitmap = ImageUtils.imageProxyToBitmap(imageProxy);
                    }
                    imageProxy.close();
                });

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

            } catch (Exception e) {
                Toast.makeText(this, "Camera failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void captureAndSaveFace() {
        if (latestFrameBitmap == null) {
            Toast.makeText(this, "Camera not ready. Try again.", Toast.LENGTH_SHORT).show();
            return;
        }

        isCaptured = true;

        Bitmap bitmap = Bitmap.createScaledBitmap(latestFrameBitmap, 112, 112, true);
        String base64Image = convertBitmapToBase64(bitmap);
        saveToFirebase(base64Image);
    }

    private String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void saveToFirebase(String base64Image) {
        String studentId = getIntent().getStringExtra("studentId");
        if (studentId == null) {
            Toast.makeText(this, "Student ID not found", Toast.LENGTH_SHORT).show();
            return;
        }

        Bitmap bitmap = ImageUtils.base64ToBitmap(base64Image);
        float[] embedding = faceEmbedder.getEmbedding(bitmap);

        List<Float> embeddingList = new ArrayList<>();
        for (float val : embedding) {
            embeddingList.add(val);
        }

        DatabaseReference embeddingsRef = FirebaseDatabase.getInstance().getReference("embeddings").child(studentId);
        DatabaseReference imageRef = FirebaseDatabase.getInstance().getReference("images").child(studentId);

        embeddingsRef.setValue(embeddingList).addOnCompleteListener(task1 -> {
            if (task1.isSuccessful()) {
                imageRef.setValue(base64Image).addOnCompleteListener(task2 -> {
                    if (task2.isSuccessful()) {
                        Toast.makeText(FaceScanActivity.this, "Face and image saved", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(FaceScanActivity.this, "Face saved, image failed", Toast.LENGTH_SHORT).show();
                    }
                    new Handler().postDelayed(this::finish, 1000);
                });
            } else {
                Toast.makeText(FaceScanActivity.this, "Failed to save face", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) {
            cameraExecutor.shutdown();
        }
    }
}
