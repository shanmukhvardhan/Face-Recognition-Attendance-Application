package com.example.faceattendanceapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class ViewAttendanceActivity extends AppCompatActivity {

    EditText dateEditText;
    ImageView backArrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance);

        dateEditText = findViewById(R.id.dateEditText);
        backArrow = findViewById(R.id.backArrow);

        // Open calendar when clicking date field
        dateEditText.setOnClickListener(view -> openDatePicker());

        // Back button
        backArrow.setOnClickListener(v -> finish());
    }

    private void openDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH); // 0-based
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    // Format date: 2-digit day/month with 0-padding
                    String formattedDate = String.format("%02d/%02d/%04d",
                            selectedDay, selectedMonth + 1, selectedYear);
                    dateEditText.setText(formattedDate);

                    // Optional: Fetch and display attendance for selected date
                    // fetchAttendanceData(formattedDate);
                },
                year, month, day
        );

        datePickerDialog.show();
    }
}
