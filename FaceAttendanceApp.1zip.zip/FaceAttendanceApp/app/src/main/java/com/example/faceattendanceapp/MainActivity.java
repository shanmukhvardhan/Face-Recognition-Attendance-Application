package com.example.faceattendanceapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Size;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private PreviewView previewView;
    private TextView attendanceStatus;
    private FaceEmbeddingExtractor embeddingExtractor;
    private ExecutorService cameraExecutor;

    private boolean isProcessing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        Button markAttendanceBtn = findViewById(R.id.markAttendanceBtn);
        Button adminBtn = findViewById(R.id.adminButton);
        attendanceStatus = findViewById(R.id.statusText);

        embeddingExtractor = new FaceEmbeddingExtractor(this);
        cameraExecutor = Executors.newSingleThreadExecutor();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 100);
        }

        markAttendanceBtn.setOnClickListener(v -> isProcessing = true);

        adminBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AdminLoginActivity.class);
            startActivity(intent);
        });
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                        .setTargetResolution(new Size(480, 640))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

                imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeImage);

                CameraSelector cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA;
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeImage(@NonNull ImageProxy imageProxy) {
        if (!isProcessing) {
            imageProxy.close();
            return;
        }

        Bitmap bitmap = YuvToRgbConverter.convertYUV420ToBitmap(this, imageProxy);
        InputImage image = InputImage.fromBitmap(bitmap, 0);

        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build();

        FaceDetector detector = FaceDetection.getClient(options);

        detector.process(image)
                .addOnSuccessListener(faces -> {
                    if (faces.size() > 0) {
                        Face face = faces.get(0);
                        embeddingExtractor.getFaceEmbedding(bitmap, face, embedding -> {
                            compareWithStoredEmbeddings(embedding);
                            isProcessing = false;
                        });
                    } else {
                        runOnUiThread(() -> attendanceStatus.setText("No face detected"));
                        isProcessing = false;
                    }
                    imageProxy.close();
                })
                .addOnFailureListener(e -> {
                    e.printStackTrace();
                    isProcessing = false;
                    imageProxy.close();
                });
    }

    private void compareWithStoredEmbeddings(float[] currentEmbedding) {
        FirebaseDatabase.getInstance().getReference("embeddings")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        boolean matched = false;
                        for (DataSnapshot child : snapshot.getChildren()) {
                            List<Double> storedList = (List<Double>) child.getValue();
                            float[] storedEmbedding = new float[storedList.size()];
                            for (int i = 0; i < storedList.size(); i++) {
                                storedEmbedding[i] = storedList.get(i).floatValue();
                            }

                            float distance = calculateDistance(currentEmbedding, storedEmbedding);
                            if (distance < 1.0f) {
                                matched = true;
                                markAttendance(child.getKey());
                                break;
                            }
                        }

                        if (!matched) {
                            runOnUiThread(() -> attendanceStatus.setText("No match found"));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        runOnUiThread(() -> attendanceStatus.setText("Database error"));
                    }
                });
    }

    private float calculateDistance(float[] emb1, float[] emb2) {
        float sum = 0f;
        for (int i = 0; i < emb1.length; i++) {
            float diff = emb1[i] - emb2[i];
            sum += diff * diff;
        }
        return (float) Math.sqrt(sum);
    }

    private void markAttendance(String rollNumber) {
        FirebaseDatabase.getInstance().getReference("attendance").child(rollNumber).setValue(true);
        runOnUiThread(() -> attendanceStatus.setText("Attendance marked for " + rollNumber));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            Toast.makeText(this, "Camera permission is required", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cameraExecutor.shutdown();
    }
}
