plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {

    packagingOptions {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/license.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt",
                "META-INF/notice.txt",
                "META-INF/ASL2.0",
                "META-INF/*.kotlin_module"
            )
        }
    }



    namespace = "com.example.faceattendanceapp"
    compileSdk = 34 // Use 34 or 33 — 35 may be unsupported yet

    defaultConfig {
        applicationId = "com.example.faceattendanceapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        viewBinding = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    // ✅ FIXED Face detection version
    implementation("com.google.mlkit:face-detection:16.1.5")

    // ✅ CameraX (working versions)
    implementation("androidx.camera:camera-core:1.1.0")
    implementation("androidx.camera:camera-camera2:1.1.0")
    implementation("androidx.camera:camera-lifecycle:1.1.0")
    implementation("androidx.camera:camera-view:1.0.0-alpha32")

    // ✅ Material Design
    implementation("com.google.android.material:material:1.9.0")

    // ✅ Firebase Realtime Database
    implementation("com.google.firebase:firebase-database:20.3.0")
    implementation("com.google.firebase:firebase-auth:22.1.1")

    //implementation("org.tensorflow:tensorflow-lite:2.9.0")
    implementation("org.tensorflow:tensorflow-lite-support:0.3.1")
    //implementation("org.tensorflow:tensorflow-lite-gpu:2.13.0")

    // ✅ Firebase Core (required for some services)
    implementation("com.google.firebase:firebase-analytics:21.6.1")

    // ✅ AppCompat for backward compatibility
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.airbnb.android:lottie:6.3.0")





}
